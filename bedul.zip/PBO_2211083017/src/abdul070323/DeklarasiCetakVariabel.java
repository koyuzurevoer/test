/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abdul070323;

/**
 *
 * @author ASUS
 */
public class DeklarasiCetakVariabel {
    public static void main (String[] args ){
            int number = 10;
            char letter;
            boolean result = true;
            String str = "hello";
            
                letter = 'a';
             System.out.println(number);
             System.out.println(letter);
             System.out.println(result);
             System.out.println(str);
    }
}
