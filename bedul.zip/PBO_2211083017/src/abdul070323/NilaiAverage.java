/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package abdul070323;

/**
 *
 * @author ASUS
 */
public class NilaiAverage {
    public static void main (String[] args ){
        int val1 = 10;
        int val2 = 20;
        int val3 = 45;
        int average;
        
        average = (val1+val2+val3)/3;
        System.out.println(average);
    }
}
