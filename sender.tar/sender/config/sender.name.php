<?php
function fromname(){
$fromname = "";


###############[ edit it for still inbox ]###############
$fn="
Amazon,
Amazon Inc,
amazon.com,
Amazon Prime
";
###############[ edit it for still inbox ]###############



//don't edit this script!!!
$fn = explode(",", $fn);
$fromname = $fn[mt_rand(0, count($fn)-1)];
return $fromname;
}
?>
