<?php
error_reporting(0);
include "config/nano.php";
include "config/sender.name.php";
include "config/sender.mail.php";

echo "
[][]=============================================================[][]

    #######################  M     M PPPPPP
    ##        __         ##  MM   MM P     P
    # #      |  |       # #  M M M M P     P
    #  ######|  |#######  #  M  M  M PPPPPP
    #        |__|         #  M     M P     _____________________
    #                     #  M     M P     |Indonesia pro - MP
    #######################  M     M P     |Casual Edition V 1.2

[][]=============================================================[][]

";

echo "
Letter File: ";
$letter = trim(fgets(STDIN));
if(file_exists("letter/$letter")){
echo "File Found!
";
}else{
echo "File Not Found!

";
return $list;
}

echo "Your List File (list.txt): ";
$list = trim(fgets(STDIN));
if(file_exists("list/$list")){
echo "File Found!
";
}else{
echo "File Not Found!

";
return $list;
}
echo "Enter Delay in Second (number only):";
$delay = trim(fgets(STDIN));
if (!preg_match("/^[1234567890]*$/",$delay)) {
echo "Invalid Input!
";
return $delay;
}
echo "
[][]======================[ START SENDING ]======================[][]

";
$i = 0;
$cox = file("list/$list");
foreach ($cox as $cok => $target){
$i++;
$cleantarget= trim($target);
$sok = "$cleantarget";
if (!filter_var($sok, FILTER_VALIDATE_EMAIL)) {
echo "
Success Send!
";
}else{

$fromnames = fromname();
$cleannames = trim($fromnames);
$frommails = frommail();
$cleanmails = trim($frommails);

$letterfile = file_get_contents("letter/$letter");

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type: text/html\r\n";
$headers .= 'From: '.$cleannames.'<'.$cleanmails.'>'. "\r\n";
if(mail($cleantarget,$title,$letterfile,$headers)){
echo "[][$i] [$cleantarget] [OK] [$cleannames] [$cleanmails]\n";
}else{
echo "[][$i] [$cleantarget] [ERROR] [$cleannames] [$cleanmails]\n";
}

sleep(1);
if ($i % 5 == 0){
echo "
[][]=============[ Delay in $delay second ]==============[][]

";
sleep($delay);
}

}
} 
echo "
[][]======================[ STOP SENDING ]======================[][]
[][]======================[   ALEXAMP    ]======================[][]
";
?>
