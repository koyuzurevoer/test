<?php
function frommail(){
$frommail = "";


###############[ edit it for still inbox ]###############
$fn="
no-reply@amazon.com,
noreply@amazon.com,
support@amazon.com
";
###############[ edit it for still inbox ]###############



//don't edit this script!!!
$fn = explode(",", $fn);
$frommail = $fn[mt_rand(0, count($fn)-1)];
return $frommail;
}
?>
